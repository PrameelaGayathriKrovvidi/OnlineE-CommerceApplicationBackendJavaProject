package com.example.demo.entity;

import java.math.BigDecimal;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="orders")
public class Order {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="order_id")
	private Long orderId;
	
	@Column(name="user_id",nullable=false)
	private int userId;
	
	@Column(name = "total_amount", nullable = false)
	private BigDecimal totalAmount;
	
	@Enumerated(EnumType.STRING)
	@Column(name="status",nullable = false)
	private OrderStatus status;
	
	@Column(name="created_at",nullable = false,updatable = false )
	private LocalDateTime createdAt;
	
	@Column(name="updated_at")
	private LocalDateTime updatedAt;
	
	@OneToMany(mappedBy="order", cascade = CascadeType.ALL,fetch=FetchType.LAZY)
	private List<OrderItem> orderItems;

	public Order() {
		
	}
	
	// Getters and setters 
	public Long getOrderId() { 
		return orderId; 
	} 
	
	public void setOrderId(Long orderId) { 
		this.orderId = orderId; 
	} 
	
	public int getUserId() { 
		return userId;
	}
	
	public void setUserId(int userId) { 
		this.userId = userId; 
	} 
	
	public BigDecimal getTotalAmount() { 
		return totalAmount; 
	} 
	
	public void setTotalAmount(BigDecimal totalAmount) { 
		this.totalAmount = totalAmount; 
		}

	public OrderStatus getStatus() { 
		return status; 
	} 
	
	public void setStatus(OrderStatus status) { 
		this.status = status; 
	} 
	
	public LocalDateTime getCreatedAt() { 
		return createdAt; 
	} 
	
	public void setCreatedAt(LocalDateTime createdAt) { 
		this.createdAt = createdAt; 
	} 
	
	public LocalDateTime getUpdatedAt() { 
		return updatedAt; 
	} 
	
	public void setUpdatedAt(LocalDateTime updatedAt) { 
		this.updatedAt = updatedAt; 
	} 
	
	public List<OrderItem> getOrderItems() { 
		return orderItems; 
	} 
	
	public void setOrderItems(List<OrderItem> orderItems) { 
		this.orderItems = orderItems; 
	} 
	

}
